public enum CarType {

    COMPACT, STANDARD, LUXURIOUS, SPORT, SUV
}
