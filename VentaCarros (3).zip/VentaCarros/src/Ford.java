
public class Ford extends Car {

    public Ford(CarType type, String carID, int maxSpeed) {
     throw new UnsupportedOperationException("Not supported yet.");}

    

}
