public interface Vehicle {

    public int increaseSpeed(int dV);

    public int decreaseSpeed(int dV);
}
